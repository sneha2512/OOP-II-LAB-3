# JavaFx Lab
This is an exercice which uses JavaFx to create a  simple video rental system UI
